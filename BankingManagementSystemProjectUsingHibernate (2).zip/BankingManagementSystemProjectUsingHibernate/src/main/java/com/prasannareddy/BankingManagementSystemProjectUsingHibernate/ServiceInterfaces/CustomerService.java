package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces;
import java.util.List;

import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Customer;
public interface CustomerService {
	void createCustomer(Customer customer);
    Customer readCustomer(int customerId);
    void updateCustomer(Customer customer);
    void deleteCustomer(int customerId);
	List<Customer> getAllCustomers();
	Customer getCustomerById(int customerId);
}
