package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceImplementation;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Card;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.CardService;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOImplementation.*;
public abstract class CardServiceImpl implements CardService {
    private CardDAO cardDAO = new CardDAOImpl();

    @Override
    public void createCard(Card card) {
        cardDAO.createCard(card);
    }

    @Override
    public Card readCard(int cardNumber) {
        return cardDAO.readCard(cardNumber);
    }

    @Override
    public void updateCard(Card card) {
        cardDAO.updateCard(card);
    }

    @Override
    public void deleteCard(int cardNumber) {
        cardDAO.deleteCard(cardNumber);
    }

	public Card getCardById(int nextInt) {
		// TODO Auto-generated method stub
		return null;
	}
}
