package com.prasannareddy.BankingManagementSystemProjectUsingHibernate;

import java.util.List;

import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Card;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.CardService;

public class CardServiceImple implements CardService {

	@Override
	public void createCard(Card card) {
		// TODO Auto-generated method stub

	}

	@Override
	public Card readCard(int cardNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateCard(Card card) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteCard(int cardNumber) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Card> getAllCards() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Card getCardById(int cardNumber) {
		// TODO Auto-generated method stub
		return null;
	}

}
