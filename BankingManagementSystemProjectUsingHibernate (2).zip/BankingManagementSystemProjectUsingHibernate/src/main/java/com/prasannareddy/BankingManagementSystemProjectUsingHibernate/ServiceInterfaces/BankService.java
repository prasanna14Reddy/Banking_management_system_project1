package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces;
import java.util.List;

import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Bank;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Branch;
public interface BankService {
	void createBank(Bank bank);
    Bank readBank(int bankCode);
    void updateBank(Bank bank);
    void deleteBank(int bankCode);
	List<Bank> getAllBanks();
	Bank getBank(int bankCode);
	static void createBranch(Branch newBranch) {
		// TODO Auto-generated method stub
		
	}
}
