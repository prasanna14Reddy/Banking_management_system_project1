package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceImplementation;
import java.util.List;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOImplementation.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.CustomerService;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Customer;
public class CustomerServiceImpl implements CustomerService {
    private CustomerDAO customerDAO = new CustomerDAOImpl();
    @Override
    public void createCustomer(Customer customer) {
        customerDAO.createCustomer(customer);
    }
    @Override
    public Customer readCustomer(int customerId) {
        return customerDAO.readCustomer(customerId);
    }
    @Override
    public void updateCustomer(Customer customer) {
        customerDAO.updateCustomer(customer);
    }
    @Override
    public void deleteCustomer(int customerId) {
        customerDAO.deleteCustomer(customerId);
    }
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}
	public Customer getCustomerById(int updateId) {
		// TODO Auto-generated method stub
		return null;
	}
}
