package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Account;
public interface AccountDAO {
	void createAccount(Account account);
    Account readAccount(int accountNumber);
    void updateAccount(Account account);
    void deleteAccount(int accountNumber);	
}
