package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites;
import jakarta.persistence.*;
@Entity
@Table(name = "Transaction")
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int transactionId;
    private java.sql.Date transactionDate;
    private String transactionType;
    private double amount;
    private int accountNumber;
    private int branchCode;
 // Getters and Setters
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public java.sql.Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(java.sql.Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public int getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(int branchCode) {
		this.branchCode = branchCode;
	}
	public void commit() {
		// TODO Auto-generated method stub
		
	}
	public void rollback() {
		// TODO Auto-generated method stub
		
	}
}
