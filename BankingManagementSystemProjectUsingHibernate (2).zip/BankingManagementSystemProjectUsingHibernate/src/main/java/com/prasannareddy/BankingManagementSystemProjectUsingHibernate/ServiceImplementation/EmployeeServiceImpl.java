package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceImplementation;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOImplementation.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Employee;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.EmployeeService;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.*;
public abstract class EmployeeServiceImpl implements EmployeeService {
    private EmployeeDAO employeeDAO = new EmployeeDAOImpl();
    @Override
    public void createEmployee(Employee employee) {
        employeeDAO.createEmployee(employee);
    }
    @Override
    public Employee readEmployee(int employeeId) {
        return employeeDAO.readEmployee(employeeId);
    }
    @Override
    public void updateEmployee(Employee employee) {
        employeeDAO.updateEmployee(employee);
    }
    @Override
    public void deleteEmployee(int employeeId) {
        employeeDAO.deleteEmployee(employeeId);
    }
}
