package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceImplementation;

import java.util.List;

import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.LoanDAO;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Loan;

public class LoanServicImpl implements LoanDAO {

	@Override
	public void createLoan(Loan loan) {
		// TODO Auto-generated method stub

	}

	@Override
	public Loan readLoan(int loanId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateLoan(Loan loan) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteLoan(int loanId) {
		// TODO Auto-generated method stub

	}

	@Override
	public Loan getLoanById(int loanId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Loan> getAllLoans() {
		// TODO Auto-generated method stub
		return null;
	}

}
