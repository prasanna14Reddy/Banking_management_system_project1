package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceImplementation;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOImplementation.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.LoanService;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Loan;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.*;
public  class LoanServiceImpl implements LoanService {
    private LoanDAO loanDAO = new LoanServicImpl();
    @Override
    public void createLoan(Loan loan) {
        loanDAO.createLoan(loan);
    }
    @Override
    public Loan readLoan(int loanId) {
        return loanDAO.readLoan(loanId);
    }
    @Override
    public void updateLoan(Loan loan) {
        loanDAO.updateLoan(loan);
    }
    @Override
    public void deleteLoan(int loanId) {
        loanDAO.deleteLoan(loanId);
    }
	@Override
	public Loan getLoanById(int loanId) {
		// TODO Auto-generated method stub
		return null;
	}
}
