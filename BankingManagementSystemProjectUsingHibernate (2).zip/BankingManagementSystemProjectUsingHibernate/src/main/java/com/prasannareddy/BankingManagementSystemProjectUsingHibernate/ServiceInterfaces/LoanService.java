package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces;
import java.util.List;

import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Loan;
public interface LoanService {
	 void createLoan(Loan loan);
	    Loan readLoan(int loanId);
	    void updateLoan(Loan loan);
	    void deleteLoan(int loanId);
		Loan getLoanById(int loanId);
		 
	}
