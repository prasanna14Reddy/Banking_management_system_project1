package com.prasannareddy.BankingManagementSystemProjectUsingHibernate;

import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Loan;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.LoanService;

public class LoanServiceImple implements LoanService {

	@Override
	public void createLoan(Loan loan) {
		// TODO Auto-generated method stub

	}

	@Override
	public Loan readLoan(int loanId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateLoan(Loan loan) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteLoan(int loanId) {
		// TODO Auto-generated method stub

	}

	@Override
	public Loan getLoanById(int loanId) {
		// TODO Auto-generated method stub
		return null;
	}

}
