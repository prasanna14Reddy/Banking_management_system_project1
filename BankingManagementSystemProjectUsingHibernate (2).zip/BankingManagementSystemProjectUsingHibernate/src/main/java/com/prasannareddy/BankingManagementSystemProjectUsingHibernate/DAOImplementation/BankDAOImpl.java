package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOImplementation;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.HibernateUtil;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.BankDAO;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Bank;
public class BankDAOImpl implements BankDAO {
    @Override
    public void createBank(Bank bank) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(bank);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    @Override
    public Bank readBank(int bankCode) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Bank.class, bankCode);
        }
    }

    @Override
    public void updateBank(Bank bank) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(bank);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    @Override
    public void deleteBank(int bankCode) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Bank bank = session.get(Bank.class, bankCode);
            if (bank != null) {
                session.delete(bank);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}
