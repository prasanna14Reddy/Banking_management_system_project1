package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceImplementation;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOImplementation.BranchDAOImpl;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.DAOInterfaces.*;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Branch;
import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces.BranchService;
public class BranchServiceImpl implements BranchService {
    private BranchDAO branchDAO = new BranchDAOImpl();
    @Override
    public void createBranch(Branch branch) {
        branchDAO.createBranch(branch);
    }
    @Override
    public Branch readBranch(int branchId) {
        return branchDAO.readBranch(branchId);
    }
    @Override
    public void updateBranch(Branch branch) {
        branchDAO.updateBranch(branch);
    }
    @Override
    public void deleteBranch(int branchId) {
        branchDAO.deleteBranch(branchId);
    }
	public Branch getBranchById(int nextInt) {
		// TODO Auto-generated method stub
		return null;
	}
}
