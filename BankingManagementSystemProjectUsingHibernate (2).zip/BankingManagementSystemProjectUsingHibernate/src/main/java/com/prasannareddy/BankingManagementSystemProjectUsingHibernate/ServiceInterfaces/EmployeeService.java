package com.prasannareddy.BankingManagementSystemProjectUsingHibernate.ServiceInterfaces;
import java.util.List;

import com.prasannareddy.BankingManagementSystemProjectUsingHibernate.Entites.Employee;
public interface EmployeeService {
	void createEmployee(Employee employee);
    Employee readEmployee(int employeeId);
    void updateEmployee(Employee employee);
    void deleteEmployee(int employeeId);
	List<Employee> getAllEmployees();
	Employee getEmployeeById(int employeeId);
}
